import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lista-itens',
  templateUrl: './lista-itens.component.html',
  styleUrls: ['./lista-itens.component.scss']
})
export class ListaItensComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
